<?php
class Category_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

        public function get_categories($slug = FALSE,$limit,$start)
		{
			$this->db->limit($limit, $start);

			if ($slug === FALSE)
			{
			        $query = $this->db->get('category_master');
			        return $query->result_array();
			}

			$query = $this->db->get_where('category_master', array('category_slug' => $slug));
			return $query->row_array();
		}

		public function record_count() {
			return $this->db->count_all("category_master");
		}


}