<?php
class Event_model extends CI_Model {

        public function __construct()
        {
                $this->load->database();
        }

        public function get_all_events()
		{

			$this->db->select('event_master.*'
							   );
			$this->db->from('event_master');

			$query = $this->db->get();
			return $query->result_array();
		}

        public function get_event($slug = FALSE, $id = FALSE)
		{
			if ($slug === FALSE && $id === FALSE )
			{
			    return FLASE;
			}

			$this->db->select('event_master.*,category_event.category_id,category_master.category_slug, 
							   DATE_FORMAT(event_master.start_date,"%b") as start_date_month,
							   DATE_FORMAT(event_master.start_date,"%d") as start_date_date,
							   DATE_FORMAT(event_master.start_date,"%W") as start_date_day,
							   DATE_FORMAT(event_master.start_date,"%b %d %Y %l:%i %p") as start_date_format,
							   DATE_FORMAT(event_master.start_date,"%l:%i %p") as start_time_format'
							   );
			$this->db->from('event_master');
			$this->db->join('ticket_seat_master', 'ticket_seat_master.event_id = event_master.id','left');
			$this->db->join('category_event', 'category_event.category_event_id = event_master.id','left');
			$this->db->join('category_master', 'category_master.cat_id = category_event.category_id','left');

			if ($id > 0) {
				$this->db->where('event_master.id', $id);
			}else{
				$this->db->where('event_master.slug', $slug);
			}

			$query = $this->db->get();

			$event_details = $query->row_array();


			$this->db->select('
							   min(ticket_seat_master.unit_price*ticket_seat_master.unit_min_purchase) as min_unit_price, 
							   max(ticket_seat_master.unit_price*ticket_seat_master.unit_min_purchase) as max_unit_price'
							   );
			$this->db->from('event_master');
			$this->db->join('ticket_seat_master', 'ticket_seat_master.event_id = event_master.id','left');
			if ($id > 0) {
				$this->db->where('event_master.id', $id);	
			}else{
				$this->db->where('event_master.slug', $slug);	
			}
			$this->db->where('ticket_seat_master.event_ticket', 'Y');
			$query = $this->db->get();

			$ticket_details =  $query->row_array();

			$event_details["min_unit_price"] = $ticket_details["min_unit_price"];
			$event_details["max_unit_price"] = $ticket_details["max_unit_price"];  


			/* Get Additional charges */
			if ($event_details["id"] > 0) {
				$this->db->select('event_additional_charges.*');
				$this->db->from('event_additional_charges');
				$this->db->where('event_additional_charges.event_id', $event_details["id"]);	
				$query = $this->db->get();
				$event_details["event_additional_charges"] = $query->result_array();
			}

			return $event_details;
		}


		public function get_event_seats($event = 0,$ticket_class_id=0)
		{
			if ($event < 1)
			{
			        return FALSE;
			}


			$group_unit_total_sql = "";
			if ( $ticket_class_id < 1 ) {
				$group_unit_total_sql = "sum(ticket_seat_master.unit_total) as group_unit_total,";
			}

			$this->db->select('ticket_seat_master.*,
							   '.$group_unit_total_sql.'
				               ticket_section.id as ticket_section_section_id,
							   ticket_section.section as ticket_section_section,
							   ticket_section.title as ticket_section_title,
							   ticket_class.id as ticket_class_id,
							   ticket_class.class as ticket_class_class,
							   ticket_class.title as ticket_class_title,
							   ticket_class.tool_tip as ticket_class_tool_tip'
							  );
			$this->db->from('ticket_seat_master');
			$this->db->where('ticket_seat_master.event_id', $event);
			if($ticket_class_id>0) { $this->db->where('ticket_seat_master.ticket_class_id', $ticket_class_id); }
			$this->db->join('ticket_class', 'ticket_class.id = ticket_seat_master.ticket_class_id','left');
			$this->db->join('ticket_section', 'ticket_section.id = ticket_class.section_id','left');	
			if ( $ticket_class_id < 1 ) {
			$this->db->group_by("ticket_seat_master.ticket_class_id"); 		
			}
			$this->db->order_by('ticket_seat_master.table_start_number ASC');
			$this->db->order_by('ticket_section.order ASC');
			$this->db->order_by('ticket_class.order ASC');
			$query = $this->db->get();
			//echo $this->db->last_query();
			return $query->result_array();
		}

		public function get_event_seats_booked($event = 0, $ticket_class_id = 0)
		{
			if ($event < 1 || $ticket_class_id <1)
			{
			        $query = $this->db->get('order_seat_details');
			        return $query->result_array();
			}
			$this->db->select('order_seat_details.seat_number as occupied_seat_number');
			$this->db->from('order_seat_details');
			$this->db->where('order_seat_details.event_id', $event);
			$this->db->where('order_seat_details.ticket_class_id', $ticket_class_id);
			$query = $this->db->get();
			$array = array();
			$result_array = $query->result_array();
			foreach($result_array  as $row) {
				$array[] = $row['occupied_seat_number'];
			}
			return $array;
		}

		public function get_event_table_booked_details($event = 0, $ticket_class_id = 0)
		{
			if ($event < 1 || $ticket_class_id <1)
			{
			        $query = $this->db->get('order_seat_details');
			        return $query->result_array();
			}
			$this->db->select('COUNT(order_seat_details.seat_number) as occupied_seat_count, order_seat_details.table_number as occupied_table_number');
			$this->db->from('order_seat_details');
			$this->db->where('order_seat_details.event_id', $event);
			$this->db->where('order_seat_details.ticket_class_id', $ticket_class_id);
			$this->db->group_by("order_seat_details.table_number"); 
			$query = $this->db->get();
			$result_array = $query->result_array();
			return $result_array;
		}



		public function get_event_missing_seats($event = 0, $ticket_class_id = 0)
		{
			if ($event < 1 || $ticket_class_id <1)
			{
			        $query = $this->db->get('ticket_missing_seats');
			        return $query->result_array();
			}
			$this->db->select('ticket_missing_seats.seat_number as missing_seat_number');
			$this->db->from('ticket_missing_seats');
			$this->db->where('ticket_missing_seats.event_id', $event);
			$this->db->where('ticket_missing_seats.ticket_class_id', $ticket_class_id);
			$query = $this->db->get();

			$array = array();
			$result_array = $query->result_array();
			foreach($result_array  as $row) {
				$array[] = $row['missing_seat_number'];
			}

			return $array;
		}





}