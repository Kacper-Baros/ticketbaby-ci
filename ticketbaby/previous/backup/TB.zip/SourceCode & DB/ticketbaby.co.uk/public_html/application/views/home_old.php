<div class="container-fluid content-bg">
    <div class="container content">
        <div class="row no-mar main-content">
        <div id="adlist" class="owl-carousel" style="padding-left:25px;padding-right:25px;">
            <div class="item"><a href="<?=base_url()?>index.php/event/movie-video-and-screen-awards"><img src="<?=base_url()?>assets/images/img01.jpg" class="img-responsive" alt=""/></a></div>
            <div class="item"><a href="<?=base_url()?>index.php/event/southport-family-day-trip"><img src="<?=base_url()?>assets/images/img02.jpg" class="img-responsive" alt=""/></a></div>
            <div class="item"><img src="<?=base_url()?>assets/images/img03.jpg" class="img-responsive" alt=""/></div>
            <div class="item"><img src="<?=base_url()?>assets/images/img04.jpg" class="img-responsive" alt=""/></div>
            <div class="item"><img src="<?=base_url()?>assets/images/img05.jpg" class="img-responsive" alt=""/></div>
            <div class="item"><img src="<?=base_url()?>assets/images/img6.jpg" class="img-responsive" alt=""/></div>
            <div class="item"><img src="<?=base_url()?>assets/images/img7.jpg" class="img-responsive" alt=""/></div>
            <div class="item"><img src="<?=base_url()?>assets/images/img8.jpg" class="img-responsive" alt=""/></div>
            </div>
        </div>
    </div>  

    <div class="container">
        <div class="row form2">
            <div class="col-xs-12">&nbsp;</div>
            <div class="col-md-3 col-xs-12 bgDark adpad20">
            <h4 class="text-center text-orang">Register with TicketBaby</h4>
                            <form class="form-home-user-register" role="form" method="post" action="<?=base_url()?>index.php/ajax/registerCustomer">    
                                <div class="form-group">
                                    <input type="text" name="customer_name" autocomplete="off" class="form-control" value="" placeholder="Name"/>
                                </div>
                                <div class="form-group">
                                    <input type="email" name="customer_email" autocomplete="off" class="form-control" value="" placeholder="Email"/>
                                </div>
                                <div class="form-group">
                                    <input type="password" name="customer_password" autocomplete="off" class="form-control" value="" placeholder="Password"/>
                                </div>
                                <div class="error-msg">ERROR</div>
                                <div class="form-group text-center">
                                    <button type="submit" class="btn btn-orang btn-danger">Sign up</button>
                                </div>
                            </form>
            </div>
            <div class="col-md-6 col-xs-12 bgOrang adpad20" style="padding-bottom:39px;">
                <h4 class="text-center text-white">Recommended Events</h4>
                <div id="slist" class="owl-carousel">
                <div class="item"><a href="<?=base_url()?>index.php/event/movie-video-and-screen-awards"><img src="<?=base_url()?>assets/images/img001.png" class="img-responsive" alt=""/></a></div>
                <div class="item"><a href="<?=base_url()?>index.php/event/southport-family-day-trip"><img src="<?=base_url()?>assets/images/img-004.jpg" class="img-responsive" alt=""/></a></div>
                <div class="item"><img src="<?=base_url()?>assets/images/img002.png" class="img-responsive" alt=""/></div>
                <div class="item"><img src="<?=base_url()?>assets/images/img003.png" class="img-responsive" alt=""/></div>
                </div><br/>
            </div>
            <div class="col-md-3 col-xs-12 bgDark adBtmPad adpad20 addd"><br/>
                <h4 class="text-center text-orang" style="margin-top:-2px;">Advertisement</h4>
                <iframe width="100%" height="171" src="https://www.youtube.com/embed/-2wG0sIAPlc" frameborder="0" allowfullscreen></iframe>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="row">
        <div class="col-xs-12">&nbsp;</div>
        <div class="col-md-3 col-xs-12 leftNo content">
        <div class="col-xs-12 bgOrang-o">
        <h4 class="text-center">let us promote your event</h4>
        </div>
        <table class="table table-striped">
        <tr>
        <td><img src="<?=base_url()?>assets/images/imgz02.jpg" class="img-responsive"/></td>
        <td class="h5">Rugby World Cup
        <img src="<?=base_url()?>assets/images/stars.png" class="img-responsive"/>
        <button class="btn btn-sm btn-xs btn-orang btn-danger" data-container="body" data-toggle="popover" data-trigger="hover" title="Rugby World Cup" data-placement="right" data-content="Its just a few month to the tournament kicks off in England, the organisers have ensured that it will be an event for all of Europe to savour. See http://www.rugbyworldcup.com/">See Details</button>
        </td>
        </tr>
        <tr>
        <td><img src="<?=base_url()?>assets/images/imgz01.jpg" class="img-responsive"/></td>
        <td class="h5">Vows Family Day
        <img src="<?=base_url()?>assets/images/stars.png" class="img-responsive"/>
        <button class="btn btn-sm btn-xs btn-orang btn-danger" data-container="body" data-toggle="popover" data-trigger="hover" title="Vows" data-placement="right" data-content="The annual family community day returns to the Bindley hall this July. With all the usual fanfair, stalls, exhibitions, food and music all makr up the fun community day.">See Details</button>
        </td>
        </tr>
        <tr>
        <td><img src="<?=base_url()?>assets/images/img004.jpg" class="img-responsive"/></td>
        <td class="h5">Rockfest
        <img src="<?=base_url()?>assets/images/stars.png" class="img-responsive"/>
        <button class="btn btn-sm btn-xs btn-orang btn-danger">See Details</button>
        </td>
        </tr>
        <tr>
        <td><img src="<?=base_url()?>assets/images/img006.jpg" class="img-responsive"/></td>
        <td class="h5">Hamilton
        <img src="<?=base_url()?>assets/images/stars.png" class="img-responsive"/>
        <button class="btn btn-sm btn-xs btn-orang btn-danger">See Details</button>
        </td>
        </tr>
        </table>
        <div class="form-group adpad">
        <button class="btn btn-sm  btn-orang btn-danger">More</button>
        </div>
        </div>
        <div class="col-md-7 col-xs-12">
        <div class="col-xs-12 visible-xs">&nbsp;</div>
        <div class="col-xs-12 bgGr1">
        <button class="btn btn-black-g btn-lg noBtmRad">Hot Tickets</button>
        <button class="btn btn-orang btn-lg f1 noBtmRad">Just Announced</button>
        </div>
        <div class="col-xs-12 bgGray form2 rightSh"><br/>
        <div class="form-group col-xs-12">
        <button class="btn btn-orang f1 pull-left btn-danger">Events <i class="glyphicon glyphicon-chevron-down"></i></button>
        <button class="btn btn-black-g pull-right">Category <i class="glyphicon glyphicon-chevron-down"></i></button><br/>
        </div>
        <div class="col-xs-12 bgWhite2">
        <p class="pull-left">
        <span class="tbabywinopenurl" data-location="<?=base_url()?>index.php/event/movie-video-and-screen-awards">Movie Video & Screen Awards</span>
        </p>
        <p class="pull-right">
        <a href="<?=base_url()?>index.php/event/movie-video-and-screen-awards">Galas & Awards</a>
        </p>
        </div>
        <div class="col-xs-12 bgWhite2">
        <p class="pull-left">
        <span class="tbabywinopenurl" data-location="<?=base_url()?>index.php/event/southport-family-day-trip">Southport Day Trip</span>
        </p>
        <p class="pull-right">
        <a href="<?=base_url()?>index.php/event/southport-family-day-trip">Family & Attractions</a>
        </p>
        </div>
        <div class="col-xs-12 bgWhite2">
        <p class="pull-left">
        Songs of Laughter with My Father
        </p>
        <p class="pull-right">
        <a href="#">Theatre & Arts</a>
        </p>
        </div>
        <div class="col-xs-12 bgWhite2">
        <p class="pull-left">
        World Comedy Clash
        </p>
        <p class="pull-right">
        <a href="#">Theatre & Arts</a>
        </p>
        </div>
        <div class="col-xs-12 bgWhite2">
        <p class="pull-left">
        Barbados Independence Dinner
        </p>
        <p class="pull-right">
        <a href="#"> Galas & Awards</a>
        </p>
        </div>
        </div>
        <div class="col-xs-12"><br/>
        <center>
        <a href="<?=base_url()?>index.php/event/movie-video-and-screen-awards"><img src="<?=base_url()?>assets/images/img0banner.jpg" class="img-responsive"/></a>
        </center>
        </div>
        <div class="col-xs-12 visible-xs">&nbsp;</div>
        </div>
        <div class="col-md-2 col-xs-12 rightNo"><center>
        <img src="<?=base_url()?>assets/images/img001.jpg" class="img-responsive"/><br/>
        <img src="<?=base_url()?>assets/images/imgHOTEL.jpg" class="img-responsive"/><br/></center>
        </div>
        </div>
    </div>
</div> 
























