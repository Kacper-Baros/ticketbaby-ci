<?php
class Setting extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->model('setting_model');
        }

        public function index()
        {
                $data['settings'] = $this->setting_model->get_settings();
                $data['title'] = 'Settings';

                $this->load->view('templates/admin/header', $data);
                $this->load->view('admin/setting', $data);
                $this->load->view('templates/admin/footer');
        }

        public function view($slug = NULL)
        {
              
                $data['settings_item'] = $this->setting_model->get_settings($slug);

                if (empty($data['settings_item']))
                {
                        show_404();
                }

                $data['title'] = $data['settings_item']['title'];

                $this->load->view('templates/admin/header', $data);
                $this->load->view('admin/setting', $data);
                $this->load->view('templates/admin/footer');
        }
}