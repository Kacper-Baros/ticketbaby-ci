<?php
class Page extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->model('page_model');
        }

        public function index()
        {
                $data['pages'] = $this->page_model->get_pages();
                $data['title'] = 'CMS Pages archive';

                $this->load->view('templates/admin/header', $data);
                $this->load->view('admin/cms/index', $data);
                $this->load->view('templates/admin/footer');
        }

        public function create()
        {
                $data['pages'] = $this->page_model->get_pages();
                $data['title'] = 'CMS Pages archive';

                $this->load->view('templates/admin/header', $data);
                $this->load->view('admin/cms/index', $data);
                $this->load->view('templates/admin/footer');
        }

        public function view($slug = NULL)
        {
              
                $data['pages_item'] = $this->page_model->get_pages($slug);

                if (empty($data['pages_item']))
                {
                        show_404();
                }

                $data['title'] = $data['pages_item']['title'];

                $this->load->view('templates/admin/header', $data);
                $this->load->view('admin/cms/view', $data);
                $this->load->view('templates/admin/footer');
        }
}