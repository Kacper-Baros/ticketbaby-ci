<?php
#session_start();
class Logout extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
    }

		public function index()
		{
  		  $this->session->unset_userdata('admin_session');
  		  #session_destroy();
  		  redirect('admin/login', 'refresh');
		}
}