<?php
class User extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->model('user_model');
        }

        public function index()
        {
                $data['users'] = $this->user_model->get_users();
                $data['title'] = 'Users archive';

                $this->load->view('templates/admin/header', $data);
                $this->load->view('admin/user/index', $data);
                $this->load->view('templates/admin/footer');
        }

        public function create()
        {
                $data['users'] = $this->user_model->get_users();
                $data['title'] = 'New Users';

                $this->load->view('templates/admin/header', $data);
                $this->load->view('admin/user/index', $data);
                $this->load->view('templates/admin/footer');
        }

        public function profile()
        {
                $data['users'] = $this->user_model->get_users();
                $data['title'] = 'My Profile';

                $this->load->view('templates/admin/header', $data);
                $this->load->view('admin/user/index', $data);
                $this->load->view('templates/admin/footer');
        }

        public function view($slug = NULL)
        {
              
                $data['users_item'] = $this->user_model->get_users($slug);
                $data['title'] = 'User Details';

                if (empty($data['users_item']))
                {
                        show_404();
                }

                $data['title'] = $data['users_item']['title'];

                $this->load->view('templates/admin/header', $data);
                $this->load->view('admin/user/view', $data);
                $this->load->view('templates/admin/footer');
        }
}