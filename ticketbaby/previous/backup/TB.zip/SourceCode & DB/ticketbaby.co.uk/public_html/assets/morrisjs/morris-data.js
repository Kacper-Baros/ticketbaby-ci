$(function() {

    Morris.Area({
        element: 'morris-area-chart',
        data: [{
            period: '2013 Q1',
            restuarants: 30,
            doctors: null,
            mechanics: 50
        }, {
            period: '2013 Q2',
            restuarants: 80,
            doctors: 90,
            mechanics: 100
        }, {
            period: '2013 Q3',
            restuarants: 23,
            doctors: 50,
            mechanics: 10
        }, {
            period: '2013 Q4',
            restuarants: 200,
            doctors: 150,
            mechanics: 300
        }, {
            period: '2014 Q1',
            restuarants: 250,
            doctors: 300,
            mechanics: 400
        }, {
            period: '2014 Q2',
            restuarants: 450,
            doctors: 400,
            mechanics: 200
        }, {
            period: '2014 Q3',
            restuarants: 260,
            doctors: 360,
            mechanics: 100
        }, {
            period: '2014 Q4',
            restuarants: 500,
            doctors: 600,
            mechanics: 700
        }, {
            period: '2015 Q1',
            restuarants: 1000,
            doctors: 800,
            mechanics: 900
        }, {
            period: '2015 Q2',
            restuarants: 1200,
            doctors: 1100,
            mechanics: 900
        }],
        xkey: 'period',
        ykeys: ['restuarants', 'doctors', 'mechanics'],
        labels: ['Restuarants', 'Doctors', 'Mechanics'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });

    Morris.Donut({
        element: 'morris-donut-chart',
        data: [{
            label: "Download Sales",
            value: 12
        }, {
            label: "In-Store Sales",
            value: 30
        }, {
            label: "Mail-Order Sales",
            value: 20
        }],
        resize: true
    });

    Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            y: '2006',
            a: 100,
            b: 90
        }, {
            y: '2007',
            a: 75,
            b: 65
        }, {
            y: '2008',
            a: 50,
            b: 40
        }, {
            y: '2009',
            a: 75,
            b: 65
        }, {
            y: '2010',
            a: 50,
            b: 40
        }, {
            y: '2011',
            a: 75,
            b: 65
        }, {
            y: '2012',
            a: 100,
            b: 90
        }],
        xkey: 'y',
        ykeys: ['a', 'b'],
        labels: ['Series A', 'Series B'],
        hideHover: 'auto',
        resize: true
    });

});
