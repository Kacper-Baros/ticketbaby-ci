Barclaycard-EPDQ
================

PHP class to manage Barclarycard EPDQ payments

See supporting files for more information, defined as follows:
form.php - initial page for submitting payment
response.php - callback page (server to server)
return.php - customer return page after payment

For additional form parameters see the Barclarycard documentation

